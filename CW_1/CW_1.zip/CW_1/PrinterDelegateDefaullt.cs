using System.Runtime.InteropServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class PrinterDelegateDefaullt : IPrinterDelegate
{
    public PrinterDelegateDefaullt() {

    }

    public virtual void ShowMessage(string message) {
        Console.Write(message);
    }

    public virtual void ShowSign(char message) {
        Console.Write(message);
    }

    public void Delegate(IPrintable printable) {
        printable.Print(this);
    }
}