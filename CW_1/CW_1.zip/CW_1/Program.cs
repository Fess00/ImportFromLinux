﻿using System.Reflection.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

Sign sign = new Sign('1');
sign.Print(new PrinterDefault());

Text txt = new Text(
	new Word("Тестируем"), new Sign(' '),
	new Word("мою"), new Sign(' '),
	new Word("архитектуру"), new Sign('!'));
txt.Print(new PrinterDefault());
txt.Print(new PrinterSpecial());

PrinterDelegateDefaullt a = new PrinterDelegateDefaullt();
a.Delegate(txt);
a.Delegate(sign);
